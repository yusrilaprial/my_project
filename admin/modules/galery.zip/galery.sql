CREATE TABLE IF NOT EXISTS `galery` (
`id_galery` int( 5 ) NOT NULL AUTO_INCREMENT PRIMARY KEY , 
 
`photo` varchar (50) NOT NULL,
`deskripsi` text  NOT NULL 
  
 )  ENGINE=MyISAM; 
 